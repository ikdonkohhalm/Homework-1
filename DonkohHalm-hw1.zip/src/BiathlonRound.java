/**
 * Created by Isaac Donkoh-Halm on 11/1/2016.
 */
public class BiathlonRound {
    int hitTargets;
    double runTime;
    public BiathlonRound (int hitTargets, double runTime){
        this.hitTargets=hitTargets;
        this.runTime=runTime;
    }


}