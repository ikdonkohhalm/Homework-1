/**
 * Created by Isaac Donkoh-Halm on 11/1/2016.
 */
public interface IEvent {
    double pointsEarned();
}
